var title = document.getElementsByTagName("title");


console.log(typeof (title[0].style));
// var keys = Object.keys(title[0].style);
var values = Object.values(title[0].style);
//console.log(title[0].style[0]);

//console.log(keys,keys.length);


/**
 * code to get the style values of an element
 * for (let i = 0; i < values.length; i++) {
 * if (values[i]=="") {
 * break;
 * }
 * console.log(title[0].style[values[i]]);
 * }
*/


/**
 * code to extract the css from the html page
 * without giving a fuck about the css file
 * we don't need that anyway
 */

/**
 * dummy code to extract elements having styles
 * from the employees submitted file
 */

/*
$(document).ready(function () {
    var cssElements = {};
    var elements = document.getElementsByTagName("*");
    for (let i = 0; i < elements.length; i++) {
        let values = Object.values(elements[i].style);
        console.log(values.length);
        if (values.length > 0) {
            let csstext = elements[i].style["cssText"].replace(";",",");
            cssElements[`${elements[i].tagName}`] = JSON.parse(`{${csstext}}`);
        }
    }
})
*/


//step 1: to extract all the elements
var elements = document.getElementsByTagName("*");
// var cssElements2 = {};
var cssElementsKeys = Object.keys(cssElements);
var flag = 0;
for (let i = 0; i < elements.length; i++) {
    flag = 0;
    let values = Object.values(elements[i].style);
    console.log(values.length);
    if (values.length > 0) {
        if (cssElementsKeys.indexOf(elements[i].tagName) != -1) {
            var keys = Object.keys(cssElementsKeys(elements[i].tagName));
            var temparr = [];
            for (let i = 0; i < keys.length; i++) {
                temparr.push(keys[i] + "." + cssElementsKeys(elements[i].tagName)[keys[i]]);
            }
            let csstext = elements[i].style["cssText"].replace(";", ",");
            currElementStyle = JSON.parse(`{${csstext}}`);
            var keys2 = Object.keys(currElementStyle);
            for (let i = 0; i < keys2.length; i++) {
                if (temparr.indexOf(keys2[i] + "." + currElementStyle[keys2[i]]) == -1) {
                    flag = 1;
                    break;
                }
            }
            if (flag) {
                console.log("false");
            } else {
                console.log("true");
            }
            /**
             * match the two style objects, if they match styling is valid
             * else it isnt
             */
        }
    }
}
