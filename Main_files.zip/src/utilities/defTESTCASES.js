var fileElements = [];
var elementnames = [];
$(document).ready(function(){
    fileElements = document.getElementsByTagName('*');

    // To test that the file elements have been loaded or not
    console.log(fileElements);
    for (let i = 1; i < fileElements.length; i++) {
        elementnames.push(fileElements[i].tagName + "." + fileElements[i].parentElement.tagName);
    }

    //To test if the element array with proper names has been created or not
    console.log(elementnames);
checkforHEADtag("HEAD","HTML");
checkforTITLEtag("TITLE","HEAD");
checkforSCRIPTtag("SCRIPT","HEAD");
checkforSCRIPTtag("SCRIPT","HEAD");
checkforBODYtag("BODY","HTML");
checkforPtag("P","BODY");
checkforH1tag("H1","BODY");
checkforSPANtag("SPAN","H1");
checkforPtag("P","BODY");
checkforDIVtag("DIV","BODY");
})

/**
            * This is the test case to check for the HEAD tag
            */ 
            function checkforHEADtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the TITLE tag
            */ 
            function checkforTITLEtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BODY tag
            */ 
            function checkforBODYtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the P tag
            */ 
            function checkforPtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the H1 tag
            */ 
            function checkforH1tag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SPAN tag
            */ 
            function checkforSPANtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the P tag
            */ 
            function checkforPtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


$(document).ready(function(){
    fileElements = document.getElementsByTagName('*');
    let elementIDS = document.querySelectorAll('*[id]')

    var scores = {};
    var TotalScore = 0;

    var testcase_CheckNavBarStructure = CheckNavBarStructure();
    if(testcase_CheckNavBarStructure){
        scores[testcase_CheckNavBarStructure] = 0.5;
    }else{
        scores[testcase_CheckNavBarStructure] = 0;
    }

    var testcase_checkNavBarHeader = checkNavBarHeader();
    if(testcase_checkNavBarHeader){
        scores[testcase_checkNavBarHeader] = 0.5;
    }else{
        scores[testcase_checkNavBarHeader] = 0;
    }

    var testcase_checkNavBarLink = checkNavBarLink();
    if(testcase_checkNavBarLink){
        scores[testcase_checkNavBarLink] = 0.5;
    }else{
        scores[testcase_checkNavBarLink] = 0;
    }

    var testcase_checkNavBarBrandName = checkNavBarBrandName();
    if(testcase_checkNavBarBrandName){
        scores[testcase_checkNavBarBrandName] = 0.5;
    }else{
        scores[testcase_checkNavBarBrandName] = 0;
    }

var testcase_CheckifID_div_isPresent = CheckifID_div_isPresent('DIV')
            if(testcase_CheckifID_div_isPresent){
                scores['testcase_CheckifID_div_isPresent'] = 0.5
                TotalScore+=0.5;
            }else{
                scores['testcase_CheckifID_div_isPresent'] = 0
            }

var testcase_CheckifID_p_isPresent = CheckifID_p_isPresent('P')
            if(testcase_CheckifID_p_isPresent){
                scores['testcase_CheckifID_p_isPresent'] = 0.5
                TotalScore+=0.5;
            }else{
                scores['testcase_CheckifID_p_isPresent'] = 0
            }

var testcase_CheckClassNameForTag_ = CheckClassNameForTag(DIV,,BODY)
                if(testcase_CheckClassNameForTag){
                    scores['testcase_CheckClassNameForTag'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag'] = 0;
                }

var testcase_CheckClassNameForTag_ = CheckClassNameForTag(P,,DIV)
                if(testcase_CheckClassNameForTag){
                    scores['testcase_CheckClassNameForTag'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag'] = 0;
                }

var testcase_CheckClassNameForTag_ = CheckClassNameForTag(P,,DIV)
                if(testcase_CheckClassNameForTag){
                    scores['testcase_CheckClassNameForTag'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag'] = 0;
                }

var testcase_CheckClassNameForTag_ = CheckClassNameForTag(SCRIPT,,BODY)
                if(testcase_CheckClassNameForTag){
                    scores['testcase_CheckClassNameForTag'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag'] = 0;
                }

var testcase_CheckclassNameforiddiv = CheckclassNameforiddiv(div,)
                if(testcase_CheckclassNameforiddiv){
                    scores['testcase_CheckclassNameforiddiv] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckclassNameforiddiv] = 0;
                }var testcase_CheckclassNameforidp = CheckclassNameforidp(p,)
                if(testcase_CheckclassNameforidp){
                    scores['testcase_CheckclassNameforidp] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckclassNameforidp] = 0;
                }})function CheckNavBarStructure(){
    try {
        if ($("nav").closest(".navbar").length>=1) {
            return true;
        } else {
            return false;

        }
    } catch (e) {
        console.error(e);
        return false;
    }
}

function checkNavBarHeader() {
    try {
        if ($("nav>div").first().closest(".navbar-header").length>=1) {
            if ($("nav>div>a").length == 1) {
                if ($("nav>div>a").closest(".navbar-brand").length>=1) {
                    return true;
                }
            }
        }
    } catch (e) {
        console.error(e);
        return false;
    }
    return false;
}

function checkNavBarLink() {
    try {
        if ($("nav li>a").length == 1) {
            //can have an if condition to check if the href link is same as said in index.html
            return true;
        }
        return false;
    } catch (e) {
        console.error(e);
        return false;
    }
}

function checkNavBarBrandName() {
    try {
        return ($("nav>a").text().trim().toLowerCase().length > 1)
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
             *  This is the function to check if the tag with ID div
             *  is present or not 
             */
            function CheckifID_div_isPresent(elementName){
            if($('#' + div).length==1 && DIV == elementName){
                return true;
            }else{
                return false;
            }
            }

/**
             *  This is the function to check if the tag with ID p
             *  is present or not 
             */
            function CheckifID_p_isPresent(elementName){
            if($('#' + p).length==1 && P == elementName){
                return true;
            }else{
                return false;
            }
            }

/**
            *   This is the function to check Classes for the DIV tag
            *   with parent as BODY
            */ 
           function CheckClassNameForTag(tagName,classname,Parent){
                let tagName_elements = $('tagname');
                for(let i=0;i<tagName_elements.length;i++){
                    if(tagName_elements[i].parentElement.tagName==Parent){
                        let classes = tagName_elements[i].className.split(" ");
                        if(classes.indexOf('classname')!=-1){
                            return true;
                        }else{
                            return false;
                        }
                    }
                }
                return false;
            }

/**
            *   This is the function to check Classes for the P tag
            *   with parent as DIV
            */ 
           function CheckClassNameForTag(tagName,classname,Parent){
                let tagName_elements = $('tagname');
                for(let i=0;i<tagName_elements.length;i++){
                    if(tagName_elements[i].parentElement.tagName==Parent){
                        let classes = tagName_elements[i].className.split(" ");
                        if(classes.indexOf('classname')!=-1){
                            return true;
                        }else{
                            return false;
                        }
                    }
                }
                return false;
            }

/**
            *   This is the function to check Classes for the P tag
            *   with parent as DIV
            */ 
           function CheckClassNameForTag(tagName,classname,Parent){
                let tagName_elements = $('tagname');
                for(let i=0;i<tagName_elements.length;i++){
                    if(tagName_elements[i].parentElement.tagName==Parent){
                        let classes = tagName_elements[i].className.split(" ");
                        if(classes.indexOf('classname')!=-1){
                            return true;
                        }else{
                            return false;
                        }
                    }
                }
                return false;
            }

/**
            *   This is the function to check Classes for the SCRIPT tag
            *   with parent as BODY
            */ 
           function CheckClassNameForTag(tagName,classname,Parent){
                let tagName_elements = $('tagname');
                for(let i=0;i<tagName_elements.length;i++){
                    if(tagName_elements[i].parentElement.tagName==Parent){
                        let classes = tagName_elements[i].className.split(" ");
                        if(classes.indexOf('classname')!=-1){
                            return true;
                        }else{
                            return false;
                        }
                    }
                }
                return false;
            }

/**
                * This is the function to check if the ID div
                * has the respective classes or not
                */ 
                function CheckclassNameforiddiv(id,classname){
                    if($('#'+div)){
                        let classes = $('#'+div).className.split(" ");
                        if(classes.indexOf(classname)!=-1){
                            return true;
                        }else{
                            return false;
                        }
                    }
                }

/**
                * This is the function to check if the ID p
                * has the respective classes or not
                */ 
                function CheckclassNameforidp(id,classname){
                    if($('#'+p)){
                        let classes = $('#'+p).className.split(" ");
                        if(classes.indexOf(classname)!=-1){
                            return true;
                        }else{
                            return false;
                        }
                    }
                }

/**
            * Function to check if the id div has the required css
            * property or not
            */ 
           function CheckForStyleID_div(id,cssProperty,cssValue){
            if($('#'+id).length==1){
                let values = Object.values($('#'+id).style);
                if(values.indexOf(cssProperty)!=-1){
                    if($('#'+id).style['cssProperty']==cssValue){
                        return true;
                    }else{
                        return false;
                    }
                }
            }
           }

