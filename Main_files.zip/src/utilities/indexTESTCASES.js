var fileElements = [];
var elementnames = [];
$(document).ready(function(){
    fileElements = document.getElementsByTagName('*');

    // To test that the file elements have been loaded or not
    console.log(fileElements);
    for (let i = 1; i < fileElements.length; i++) {
        elementnames.push(fileElements[i].tagName + "." + fileElements[i].parentElement.tagName);
    }

    //To test if the element array with proper names has been created or not
    console.log(elementnames);
checkforHEADtag("HEAD","HTML");
checkforTITLEtag("TITLE","HEAD");
checkforLINKtag("LINK","HEAD");
checkforLINKtag("LINK","HEAD");
checkforSCRIPTtag("SCRIPT","HEAD");
checkforBODYtag("BODY","HTML");
checkforHEADERtag("HEADER","BODY");
checkforNAVtag("NAV","HEADER");
checkforAtag("A","NAV");
checkforBRtag("BR","BODY");
checkforSECTIONtag("SECTION","BODY");
checkforH1tag("H1","SECTION");
checkforBRtag("BR","SECTION");
checkforBRtag("BR","SECTION");
checkforDIVtag("DIV","SECTION");
checkforDIVtag("DIV","DIV");
checkforDIVtag("DIV","DIV");
checkforPtag("P","DIV");
checkforBRtag("BR","DIV");
checkforDIVtag("DIV","DIV");
checkforDIVtag("DIV","DIV");
checkforIMGtag("IMG","DIV");
checkforBRtag("BR","DIV");
checkforAtag("A","DIV");
checkforH5tag("H5","A");
checkforSCRIPTtag("SCRIPT","BODY");
checkforSCRIPTtag("SCRIPT","BODY");
})

/**
            * This is the test case to check for the HEAD tag
            */ 
            function checkforHEADtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the TITLE tag
            */ 
            function checkforTITLEtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LINK tag
            */ 
            function checkforLINKtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LINK tag
            */ 
            function checkforLINKtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BODY tag
            */ 
            function checkforBODYtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the HEADER tag
            */ 
            function checkforHEADERtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the NAV tag
            */ 
            function checkforNAVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the A tag
            */ 
            function checkforAtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BR tag
            */ 
            function checkforBRtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SECTION tag
            */ 
            function checkforSECTIONtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the H1 tag
            */ 
            function checkforH1tag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BR tag
            */ 
            function checkforBRtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BR tag
            */ 
            function checkforBRtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the P tag
            */ 
            function checkforPtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BR tag
            */ 
            function checkforBRtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the IMG tag
            */ 
            function checkforIMGtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BR tag
            */ 
            function checkforBRtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the A tag
            */ 
            function checkforAtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the H5 tag
            */ 
            function checkforH5tag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


