var fileElements = [];
var elementnames = [];
$(document).ready(function(){
    fileElements = document.getElementsByTagName('*');

    // To test that the file elements have been loaded or not
    console.log(fileElements);
    for (let i = 1; i < fileElements.length; i++) {
        elementnames.push(fileElements[i].tagName + "." + fileElements[i].parentElement.tagName);
    }

    //To test if the element array with proper names has been created or not
    console.log(elementnames);
checkforHEADtag("HEAD","HTML");
checkforTITLEtag("TITLE","HEAD");
checkforSCRIPTtag("SCRIPT","HEAD");
checkforSCRIPTtag("SCRIPT","HEAD");
checkforBODYtag("BODY","HTML");
checkforDIVtag("DIV","BODY");
checkforPtag("P","DIV");
checkforPtag("P","DIV");
CheckIfIDDIVIsPresent("DIV");
CheckIfIDPIsPresent("P");
CheckIDForClassName("div","abc");
CheckIDForClassName("div","def");
CheckIDForClassName("div","large");
})

/**
            * This is the test case to check for the HEAD tag
            */ 
            function checkforHEADtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the TITLE tag
            */ 
            function checkforTITLEtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BODY tag
            */ 
            function checkforBODYtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the P tag
            */ 
            function checkforPtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the P tag
            */ 
            function checkforPtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            *this function is to check if the element with given id div
            *is present or not
            */
           function CheckIfIDDIVIsPresent(elementName){
               let el = $('#'+'div');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }

        function CheckifID_div_isPresent(elementName) {
            if (jQuery('#' + div).length == 1 && DIV == elementName) {
                return true;
            } else {
                return false;
            }
        }


/**
            *this function is to check if the element with given id p
            *is present or not
            */
           function CheckIfIDPIsPresent(elementName){
               let el = $('#'+'p');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
                * This function is to check if the given id div has the class
                * abc mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id div has the class
                * def mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id div has the class
                * large mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


