$(document).ready(function(){
    fileElements = document.getElementsByTagName('*');
    let elementIDS = document.querySelectorAll('*[id]')

    var scores = {};
    var TotalScore = 0;

    var testcase_CheckNavBarStructure = CheckNavBarStructure();
    if(testcase_CheckNavBarStructure){
        scores['testcase_CheckNavBarStructure'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_CheckNavBarStructure'] = 0;
    }

    var testcase_checkNavBarHeader = checkNavBarHeader();
    if(testcase_checkNavBarHeader){
        scores['testcase_checkNavBarHeader'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_checkNavBarHeader'] = 0;
    }

    var testcase_checkNavBarLink = checkNavBarLink();
    if(testcase_checkNavBarLink){
        scores['testcase_checkNavBarLink'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_checkNavBarLink'] = 0;
    }

    var testcase_checkNavBarBrandName = checkNavBarBrandName();
    if(testcase_checkNavBarBrandName){
        scores['testcase_checkNavBarBrandName'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_checkNavBarBrandName'] = 0;
    }

var testcase_CheckifIDisPresent_div = CheckifIDisPresent('div,DIV')
            if(testcase_CheckifIDisPresent_div){
                scores['testcase_CheckifIDisPresent_div'] = 0.5;
                TotalScore+=0.5;
            }else{
                scores['testcase_CheckifIDisPresent_div'] = 0;
            }

var testcase_CheckifIDisPresent_p = CheckifIDisPresent('p,P')
            if(testcase_CheckifIDisPresent_p){
                scores['testcase_CheckifIDisPresent_p'] = 0.5;
                TotalScore+=0.5;
            }else{
                scores['testcase_CheckifIDisPresent_p'] = 0;
            }

displayMarks()
})
function CheckNavBarStructure(){
    try {
        if ($("nav").closest(".navbar").length>=1) {
            return true;
        } else {
            return false;

        }
    } catch (e) {
        console.error(e);
        return false;
    }
}

function checkNavBarHeader() {
    try {
        if ($("nav>div").first().closest(".navbar-header").length>=1) {
            if ($("nav>div>a").length == 1) {
                if ($("nav>div>a").closest(".navbar-brand").length>=1) {
                    return true;
                }
            }
        }
    } catch (e) {
        console.error(e);
        return false;
    }
    return false;
}

function checkNavBarLink() {
    try {
        if ($("nav li>a").length == 1) {
            //can have an if condition to check if the href link is same as said in index.html
            return true;
        }
        return false;
    } catch (e) {
        console.error(e);
        return false;
    }
}

function checkNavBarBrandName() {
    try {
        return ($("nav>a").text().trim().toLowerCase().length > 1)
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
             *  This is the function to check if the tag with specific ID 
             *  is present or not 
             */
            function CheckifIDisPresent(id,elementName){
            if($('#' + id)[0].length==1 && elementName == "$('#' + id)[0].tagName"){
                return true;
            }else{
                return false;
            }
            }

/**
        *   This is the function to check Classes for all tags
        */ 
       function CheckClassNameForTag(tagName,classname,Parent){
            let tagName_elements = $(String(tagName));
            for(let i=0;i<tagName_elements.length;i++){
                if(tagName_elements[i].parentElement.tagName==Parent){
                    let classes = tagName_elements[i].className.split(" ");
                    if(classes.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }
            }
            return false;
        }

/**
            * This is the function to check if each ID
            * has the respective classes or not
            */ 
            function CheckclassNameforid(id,classname){
                if($('#'+id)){
                    let classes = $('#'+id).className.split(" ");
                    if(classes.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }
            }

function displayMarks() {
                var sum = 0;
                for (property in scores) {
        
                    if (scores[property] == 0) {
                        console.error(property + "=>" + scores[property])
                    } else {
                        console.log(property + "=>" + scores[property]);
                    }
                    sum = sum + scores[property];
                }
                console.log("Sum is " + sum);
        
                var score = JSON.parse(localStorage.getItem($("#tt_empId").text()));
                score.registerTestcases = scores;
        
                score.totalMarks = sum + score.totalMarks;
        
                console.log("Regiter score is " + JSON.stringify(score));
        
        
                var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance 
                xmlhttp.open("POST", "http://localhost:3000/post");
                xmlhttp.setRequestHeader("Content-Type", "application/json");
                xmlhttp.send(JSON.stringify(score));
        
            };