var fileElements = [];
var elementnames = [];
$(document).ready(function(){
    fileElements = document.getElementsByTagName('*');

    // To test that the file elements have been loaded or not
    console.log(fileElements);
    for (let i = 1; i < fileElements.length; i++) {
        elementnames.push(fileElements[i].tagName + "." + fileElements[i].parentElement.tagName);
    }

    //To test if the element array with proper names has been created or not
    console.log(elementnames);
checkforHEADtag("HEAD","HTML");
checkforTITLEtag("TITLE","HEAD");
checkforLINKtag("LINK","HEAD");
checkforLINKtag("LINK","HEAD");
checkforSCRIPTtag("SCRIPT","HEAD");
checkforSCRIPTtag("SCRIPT","HEAD");
checkforBODYtag("BODY","HTML");
checkforHEADERtag("HEADER","BODY");
checkforNAVtag("NAV","HEADER");
checkforAtag("A","NAV");
checkforBRtag("BR","BODY");
checkforSECTIONtag("SECTION","BODY");
checkforDIVtag("DIV","SECTION");
checkforDIVtag("DIV","DIV");
checkforBRtag("BR","DIV");
checkforFORMtag("FORM","DIV");
checkforH4tag("H4","FORM");
checkforBRtag("BR","FORM");
checkforDIVtag("DIV","FORM");
checkforLABELtag("LABEL","DIV");
checkforSELECTtag("SELECT","DIV");
checkforOPTIONtag("OPTION","SELECT");
checkforOPTIONtag("OPTION","SELECT");
checkforOPTIONtag("OPTION","SELECT");
checkforOPTIONtag("OPTION","SELECT");
checkforDIVtag("DIV","FORM");
checkforLABELtag("LABEL","DIV");
checkforINPUTtag("INPUT","DIV");
checkforDIVtag("DIV","FORM");
checkforLABELtag("LABEL","DIV");
checkforINPUTtag("INPUT","DIV");
checkforDIVtag("DIV","DIV");
checkforDIVtag("DIV","DIV");
checkforDIVtag("DIV","FORM");
checkforLABELtag("LABEL","DIV");
checkforINPUTtag("INPUT","DIV");
checkforDIVtag("DIV","DIV");
checkforDIVtag("DIV","FORM");
checkforLABELtag("LABEL","DIV");
checkforINPUTtag("INPUT","DIV");
checkforDIVtag("DIV","FORM");
checkforLABELtag("LABEL","DIV");
checkforINPUTtag("INPUT","DIV");
checkforLABELtag("LABEL","DIV");
checkforINPUTtag("INPUT","DIV");
checkforLABELtag("LABEL","DIV");
checkforINPUTtag("INPUT","DIV");
checkforLABELtag("LABEL","DIV");
checkforDIVtag("DIV","FORM");
checkforINPUTtag("INPUT","DIV");
checkforDIVtag("DIV","DIV");
checkforBRtag("BR","SECTION");
checkforSCRIPTtag("SCRIPT","BODY");
checkforSCRIPTtag("SCRIPT","BODY");
checkforSCRIPTtag("SCRIPT","BODY");
checkforSCRIPTtag("SCRIPT","BODY");
CheckIfIDEVENTIsPresent("SELECT");
CheckIfIDUSERIsPresent("INPUT");
CheckIfIDNOTIsPresent("INPUT");
CheckIfIDMESSAGEIsPresent("DIV");
CheckIfIDAVAILABILITYERRORIsPresent("DIV");
CheckIfIDDOCIsPresent("INPUT");
CheckIfIDDATEERRORIsPresent("DIV");
CheckIfIDCNIsPresent("INPUT");
CheckIfIDBIsPresent("INPUT");
CheckIfIDMIsPresent("INPUT");
CheckIfIDCIsPresent("INPUT");
CheckIfIDBTNIsPresent("INPUT");
CheckIfIDSUCCESSMESSAGEIsPresent("DIV");
CheckIDForClassName("event","form-control");
CheckIDForClassName("user","form-control");
CheckIDForClassName("not","form-control");
CheckIDForClassName("message","text-primary");
CheckIDForClassName("availabilityError","text-danger");
CheckIDForClassName("doc","form-control");
CheckIDForClassName("dateError","text-danger");
CheckIDForClassName("cn","form-control");
CheckIDForClassName("btn","btn");
CheckIDForClassName("btn","btn-primary");
CheckIDForClassName("successMessage","text-success");
})

/**
            * This is the test case to check for the HEAD tag
            */ 
            function checkforHEADtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the TITLE tag
            */ 
            function checkforTITLEtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LINK tag
            */ 
            function checkforLINKtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LINK tag
            */ 
            function checkforLINKtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BODY tag
            */ 
            function checkforBODYtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the HEADER tag
            */ 
            function checkforHEADERtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the NAV tag
            */ 
            function checkforNAVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the A tag
            */ 
            function checkforAtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BR tag
            */ 
            function checkforBRtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SECTION tag
            */ 
            function checkforSECTIONtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BR tag
            */ 
            function checkforBRtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the FORM tag
            */ 
            function checkforFORMtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the H4 tag
            */ 
            function checkforH4tag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BR tag
            */ 
            function checkforBRtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LABEL tag
            */ 
            function checkforLABELtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SELECT tag
            */ 
            function checkforSELECTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the OPTION tag
            */ 
            function checkforOPTIONtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the OPTION tag
            */ 
            function checkforOPTIONtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the OPTION tag
            */ 
            function checkforOPTIONtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the OPTION tag
            */ 
            function checkforOPTIONtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LABEL tag
            */ 
            function checkforLABELtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the INPUT tag
            */ 
            function checkforINPUTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LABEL tag
            */ 
            function checkforLABELtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the INPUT tag
            */ 
            function checkforINPUTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LABEL tag
            */ 
            function checkforLABELtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the INPUT tag
            */ 
            function checkforINPUTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LABEL tag
            */ 
            function checkforLABELtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the INPUT tag
            */ 
            function checkforINPUTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LABEL tag
            */ 
            function checkforLABELtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the INPUT tag
            */ 
            function checkforINPUTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LABEL tag
            */ 
            function checkforLABELtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the INPUT tag
            */ 
            function checkforINPUTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LABEL tag
            */ 
            function checkforLABELtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the INPUT tag
            */ 
            function checkforINPUTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the LABEL tag
            */ 
            function checkforLABELtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the INPUT tag
            */ 
            function checkforINPUTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the DIV tag
            */ 
            function checkforDIVtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the BR tag
            */ 
            function checkforBRtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            * This is the test case to check for the SCRIPT tag
            */ 
            function checkforSCRIPTtag(elementname,parentname){
                try {
                    if(elementname=="HEAD" || elementname=="BODY"){
                        if ($(elementname).length == 1 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                            console.log("true");
                    }
                }else {
                        if ($(elementname).length > 0 && elementnames.indexOf(elementname+'.'+parentname)!=-1) {
                        console.log("true");
                    } else {
                        console.log("false");
                    }
                }
                } catch (e) {
                    console.error(e);
                    return false;
                }
            }


/**
            *this function is to check if the element with given id event
            *is present or not
            */
           function CheckIfIDEVENTIsPresent(elementName){
               let el = $('#'+'event');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id user
            *is present or not
            */
           function CheckIfIDUSERIsPresent(elementName){
               let el = $('#'+'user');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id not
            *is present or not
            */
           function CheckIfIDNOTIsPresent(elementName){
               let el = $('#'+'not');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id message
            *is present or not
            */
           function CheckIfIDMESSAGEIsPresent(elementName){
               let el = $('#'+'message');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id availabilityError
            *is present or not
            */
           function CheckIfIDAVAILABILITYERRORIsPresent(elementName){
               let el = $('#'+'availabilityError');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id doc
            *is present or not
            */
           function CheckIfIDDOCIsPresent(elementName){
               let el = $('#'+'doc');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id dateError
            *is present or not
            */
           function CheckIfIDDATEERRORIsPresent(elementName){
               let el = $('#'+'dateError');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id cn
            *is present or not
            */
           function CheckIfIDCNIsPresent(elementName){
               let el = $('#'+'cn');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id B
            *is present or not
            */
           function CheckIfIDBIsPresent(elementName){
               let el = $('#'+'B');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id M
            *is present or not
            */
           function CheckIfIDMIsPresent(elementName){
               let el = $('#'+'M');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id C
            *is present or not
            */
           function CheckIfIDCIsPresent(elementName){
               let el = $('#'+'C');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id btn
            *is present or not
            */
           function CheckIfIDBTNIsPresent(elementName){
               let el = $('#'+'btn');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
            *this function is to check if the element with given id successMessage
            *is present or not
            */
           function CheckIfIDSUCCESSMESSAGEIsPresent(elementName){
               let el = $('#'+'successMessage');
            if(el.length == 1 && el[0].tagName==elementName){
                return true;
            }else{
                return false;
            }
        }


/**
                * This function is to check if the given id event has the class
                * form-control mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id user has the class
                * form-control mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id not has the class
                * form-control mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id message has the class
                * text-primary mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id availabilityError has the class
                * text-danger mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id doc has the class
                * form-control mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id dateError has the class
                * text-danger mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id cn has the class
                * form-control mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id btn has the class
                * btn mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id btn has the class
                * btn-primary mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


/**
                * This function is to check if the given id successMessage has the class
                * text-success mentioned or not
                */ 
               function CheckIDForClassName(id,classname){
                    let classes2 = $('#'+id)[0].className.split(" ");
                    if(classes2.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }


