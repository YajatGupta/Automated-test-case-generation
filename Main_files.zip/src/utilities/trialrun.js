// const fs = require('fs');

// var temp = fs.readdirSync("./");

// console.log(temp.length);


/*this is the main code to extract the dom elements
from the respective html and css documents */

// const jsdom = require('jsdom').JSDOM;

// url='./correctSolution/abc.html';

// options = {
//     runScripts: 'dangerously',
//     resources: "usable"
// };

// jsdom.fromFile(url,options).then(dom=>{
//     let window = dom.window;
//     document = window.document;
//     elements = document.getElementsByTagName('*');
//     for(let i=1;i<elements.length;i++){
//         console.log(elements[i].tagName,"---parent--->",elements[i].parentElement.tagName);
//     }
// }).catch(e=>{
//     console.log(e.message);
// })

var elements = document.querySelectorAll('*[id]');
console.log(elements);
console.log(elements.length);