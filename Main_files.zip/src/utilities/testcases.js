var fileElements = [];
var elementnames = [];

$(document).ready(function () {
    fileElements = document.getElementsByTagName('*');
    console.log(fileElements);
    for (let i = 1; i < fileElements.length; i++) {
        elementnames.push(fileElements[i].tagName + "." + fileElements[i].parentElement.tagName);
    }
    console.log(elementnames);
    checkforHEADtag("HEAD", "HTML");
    checkforTITLEtag("TITLE", "HEAD");
    //.slice(1,).map(element=>element.tagName+'.'+element.parentElement.tagName);
});


function checkforHEADtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforHEADtag("HEAD", "HTML");

function checkforTITLEtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforTITLEtag("TITLE", "HEAD");

function checkforBODYtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforBODYtag("BODY", "HTML");

function checkforHEADtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforHEADtag("HEAD", "HTML");

function checkforTITLEtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforTITLEtag("TITLE", "HEAD");

function checkforSCRIPTtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforSCRIPTtag("SCRIPT", "HEAD");

function checkforBODYtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforBODYtag("BODY", "HTML");

function checkforPtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforPtag("P", "BODY");

function checkforH1tag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforH1tag("H1", "BODY");

function checkforSPANtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforSPANtag("SPAN", "H1");

function checkforPtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforPtag("P", "H1");

function checkforPtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforPtag("P", "BODY");

function checkforDIVtag(elementname, parentname) {
    try {
        if ($(elementname).length == 1 && elementnames.indexOf(elementname + '.' + parentname) != -1) {
            console.log("true");
        } else {
            console.log("false");
        }
    } catch (e) {
        console.error(e);
        return false;
    }
}
checkforDIVtag("DIV", "BODY");

