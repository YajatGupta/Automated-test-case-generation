// var numberofscripts = document.getElementsByTagName('script');
// console.log("this is the number of the script tags",numberofscripts.length);
//const lodash = require('lodash');


$(document).ready(function(){
    console.log("aaaaaaaaaaaaaaaaaa");  
    const arrayOfElements = document.getElementsByTagName('*');
    for(var i=0;i<arrayOfElements.length;i++){
        console.log("Element is : ",arrayOfElements[i].tagName);
    }
    
})