$(document).ready(function(){
    fileElements = document.getElementsByTagName('*');
    let elementIDS = document.querySelectorAll('*[id]')

    var scores = {};
    var TotalScore = 0;

    var testcase_CheckNavBarStructure = CheckNavBarStructure();
    if(testcase_CheckNavBarStructure){
        scores['testcase_CheckNavBarStructure'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_CheckNavBarStructure'] = 0;
    }

    var testcase_checkNavBarHeader = checkNavBarHeader();
    if(testcase_checkNavBarHeader){
        scores['testcase_checkNavBarHeader'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_checkNavBarHeader'] = 0;
    }

    var testcase_checkNavBarLink = checkNavBarLink();
    if(testcase_checkNavBarLink){
        scores['testcase_checkNavBarLink'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_checkNavBarLink'] = 0;
    }

    var testcase_checkNavBarBrandName = checkNavBarBrandName();
    if(testcase_checkNavBarBrandName){
        scores['testcase_checkNavBarBrandName'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_checkNavBarBrandName'] = 0;
    }

var testcase_CheckClassNameForTag_B80 = CheckClassNameForTag('NAV','navbar','HEADER')
                if(testcase_CheckClassNameForTag_B80){
                    scores['testcase_CheckClassNameForTag_B80'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B80'] = 0;
                }

var testcase_CheckClassNameForTag_B81 = CheckClassNameForTag('NAV','navbar-expand-sm','HEADER')
                if(testcase_CheckClassNameForTag_B81){
                    scores['testcase_CheckClassNameForTag_B81'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B81'] = 0;
                }

var testcase_CheckClassNameForTag_B82 = CheckClassNameForTag('NAV','bg-dark','HEADER')
                if(testcase_CheckClassNameForTag_B82){
                    scores['testcase_CheckClassNameForTag_B82'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B82'] = 0;
                }

var testcase_CheckClassNameForTag_B83 = CheckClassNameForTag('NAV','navbar-dark','HEADER')
                if(testcase_CheckClassNameForTag_B83){
                    scores['testcase_CheckClassNameForTag_B83'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B83'] = 0;
                }

var testcase_CheckClassNameForTag_B90 = CheckClassNameForTag('A','navbar-brand','NAV')
                if(testcase_CheckClassNameForTag_B90){
                    scores['testcase_CheckClassNameForTag_B90'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B90'] = 0;
                }

var testcase_CheckClassNameForTag_B120 = CheckClassNameForTag('H1','text-center','SECTION')
                if(testcase_CheckClassNameForTag_B120){
                    scores['testcase_CheckClassNameForTag_B120'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B120'] = 0;
                }

var testcase_CheckClassNameForTag_B150 = CheckClassNameForTag('DIV','container-fluid','SECTION')
                if(testcase_CheckClassNameForTag_B150){
                    scores['testcase_CheckClassNameForTag_B150'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B150'] = 0;
                }

var testcase_CheckClassNameForTag_B160 = CheckClassNameForTag('DIV','row','DIV')
                if(testcase_CheckClassNameForTag_B160){
                    scores['testcase_CheckClassNameForTag_B160'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B160'] = 0;
                }

var testcase_CheckClassNameForTag_B170 = CheckClassNameForTag('DIV','col-md-10','DIV')
                if(testcase_CheckClassNameForTag_B170){
                    scores['testcase_CheckClassNameForTag_B170'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B170'] = 0;
                }

var testcase_CheckClassNameForTag_B171 = CheckClassNameForTag('DIV','offset-md-2','DIV')
                if(testcase_CheckClassNameForTag_B171){
                    scores['testcase_CheckClassNameForTag_B171'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B171'] = 0;
                }

var testcase_CheckClassNameForTag_B180 = CheckClassNameForTag('P','paragraph','DIV')
                if(testcase_CheckClassNameForTag_B180){
                    scores['testcase_CheckClassNameForTag_B180'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B180'] = 0;
                }

var testcase_CheckClassNameForTag_B200 = CheckClassNameForTag('DIV','row','DIV')
                if(testcase_CheckClassNameForTag_B200){
                    scores['testcase_CheckClassNameForTag_B200'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B200'] = 0;
                }

var testcase_CheckClassNameForTag_B210 = CheckClassNameForTag('DIV','col-md-4','DIV')
                if(testcase_CheckClassNameForTag_B210){
                    scores['testcase_CheckClassNameForTag_B210'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B210'] = 0;
                }

var testcase_CheckClassNameForTag_B211 = CheckClassNameForTag('DIV','offset-md-4','DIV')
                if(testcase_CheckClassNameForTag_B211){
                    scores['testcase_CheckClassNameForTag_B211'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B211'] = 0;
                }

var testcase_CheckClassNameForTag_B220 = CheckClassNameForTag('IMG','concert','DIV')
                if(testcase_CheckClassNameForTag_B220){
                    scores['testcase_CheckClassNameForTag_B220'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B220'] = 0;
                }

var testcase_CheckClassNameForTag_B250 = CheckClassNameForTag('H5','text-center','A')
                if(testcase_CheckClassNameForTag_B250){
                    scores['testcase_CheckClassNameForTag_B250'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_CheckClassNameForTag_B250'] = 0;
                }

(function () {
                var sum = 0;
                for (property in scores) {
        
                    if (scores[property] == 0) {
                        console.error(property + "=>" + scores[property])
                    } else {
                        console.log(property + "=>" + scores[property]);
                    }
                    sum = sum + scores[property];
                }
                console.log("Sum is " + sum);
        
        
                var indexData = {
                    "empId": $("#tt_empId").text(),
                    "examID": $("#tt_examId").text(),
                    "indexTestcases": scores,
                    "registerTestcases": null,
                    "totalMarks": sum
                }
        
                console.log(indexData);
                localStorage.removeItem(indexData.empId);
                localStorage.setItem(indexData.empId, JSON.stringify(indexData));
        
        
            })();})
function CheckNavBarStructure(){
    try {
        if ($("nav").closest(".navbar").length>=1) {
            return true;
        } else {
            return false;

        }
    } catch (e) {
        console.error(e);
        return false;
    }
}

function checkNavBarHeader() {
    try {
        if ($("nav>div").first().closest(".navbar-header").length>=1) {
            if ($("nav>div>a").length == 1) {
                if ($("nav>div>a").closest(".navbar-brand").length>=1) {
                    return true;
                }
            }
        }
    } catch (e) {
        console.error(e);
        return false;
    }
    return false;
}

function checkNavBarLink() {
    try {
        if ($("nav li>a").length == 1) {
            //can have an if condition to check if the href link is same as said in index.html
            return true;
        }
        return false;
    } catch (e) {
        console.error(e);
        return false;
    }
}

function checkNavBarBrandName() {
    try {
        return ($("nav>a").text().trim().toLowerCase().length > 1)
    } catch (e) {
        console.error(e);
        return false;
    }
}

/**
             *  This is the function to check if the tag with specific ID 
             *  is present or not 
             */
            function CheckifIDisPresent(id,elementName){
            if($('#' + id)[0].length==1 && elementName == "$('#' + id)[0].tagName"){
                return true;
            }else{
                return false;
            }
            }

/**
        *   This is the function to check Classes for all tags
        */ 
       function CheckClassNameForTag(tagName,classname,Parent){
            let tagName_elements = $(String(tagName));
            for(let i=0;i<tagName_elements.length;i++){
                if(tagName_elements[i].parentElement.tagName==Parent){
                    let classes = tagName_elements[i].className.split(" ");
                    if(classes.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }
            }
            return false;
        }

/**
            * This is the function to check if each ID
            * has the respective classes or not
            */ 
            function CheckclassNameforid(id,classname){
                if($('#'+id)){
                    let classes = $('#'+id).className.split(" ");
                    if(classes.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }
            }

