const fs = require('fs');
const fse = require('fs-extra');

var deleteFolderRecursive = function (path) {
    if (fs.existsSync(path)) {
        fs.readdirSync(path).forEach(function (file) {
            var curPath = path + "/" + file;
            if (fs.lstatSync(curPath).isDirectory()) { // recurse to delete the files inside the folder
                deleteFolderRecursive(curPath);
            } else { // delete file
                fs.unlinkSync(curPath);
            }
        });
        fs.rmdirSync(path);
    }
};


    
    /* deleting the files and folder and
    clearing the destination folder before writing new files into it*/

    var files = fs.readdirSync("../testfiles");
    if (files.length > 0) {
        files.forEach(file => {
            filename = file + "";
            path = "../testfiles/" + filename;
            if (fs.lstatSync(path).isDirectory()) { // recurse
                deleteFolderRecursive(path);
            } else { // delete file
                fs.unlinkSync(path);
            }
        })
    }

    fs.mkdirSync("../testfiles/htmlfiles"); //making the directory in the desired folder
    fs.mkdirSync("../testfiles/cssfiles");

    fs.readdirSync("../utilities/correctSolution/").forEach(file => {
        
        /* copying the main html and css file for main automation
        of testcases. file being copied into the desired folder */


        var filename = file + "";
        if (filename == "css") {
            console.log("css file found");
            console.log("------------");
            fse.copySync('../utilities/correctSolution/css', '../testfiles/cssfiles');
        } else {
            console.log(filename);
            mainname = filename.split(".")[0]
            console.log(mainname);
            extension = filename.split(".")[1].toLowerCase();
            console.log("----------->", extension);
            if (extension == "html" || extension == "htm") {
                console.log("true");
                var data = fs.readFileSync("../utilities/correctSolution/" + filename, "UTF-8");
                fs.writeFileSync('../testfiles/htmlfiles/' + mainname + '.html', data);
            }
        }

    })

