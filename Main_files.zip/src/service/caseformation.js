const jsdom = require('jsdom').JSDOM;
const fs = require('fs');

var maincode = `$(document).ready(function(){
    fileElements = document.getElementsByTagName('*');
    let elementIDS = document.querySelectorAll('*[id]')

    var scores = {};
    var TotalScore = 0;

    var testcase_CheckNavBarStructure = CheckNavBarStructure();
    if(testcase_CheckNavBarStructure){
        scores['testcase_CheckNavBarStructure'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_CheckNavBarStructure'] = 0;
    }

    var testcase_checkNavBarHeader = checkNavBarHeader();
    if(testcase_checkNavBarHeader){
        scores['testcase_checkNavBarHeader'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_checkNavBarHeader'] = 0;
    }

    var testcase_checkNavBarLink = checkNavBarLink();
    if(testcase_checkNavBarLink){
        scores['testcase_checkNavBarLink'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_checkNavBarLink'] = 0;
    }

    var testcase_checkNavBarBrandName = checkNavBarBrandName();
    if(testcase_checkNavBarBrandName){
        scores['testcase_checkNavBarBrandName'] = 0.5;
        TotalScore += 0.5;
    }else{
        scores['testcase_checkNavBarBrandName'] = 0;
    }\n\n`;

/**
 * data variables needed to store dynamic values
 */
var URL = [];
var funcCalls = "";
var testcases = "";
var options = {
    runScripts: 'dangerously',
    resources: "usable"
};


/**
 * Functions to check everything for the navbar
 */
testcases += `function CheckNavBarStructure(){
    try {
        if ($("nav").closest(".navbar").length>=1) {
            return true;
        } else {
            return false;

        }
    } catch (e) {
        console.error(e);
        return false;
    }
}\n\n`

testcases += `function checkNavBarHeader() {
    try {
        if ($("nav>div").first().closest(".navbar-header").length>=1) {
            if ($("nav>div>a").length == 1) {
                if ($("nav>div>a").closest(".navbar-brand").length>=1) {
                    return true;
                }
            }
        }
    } catch (e) {
        console.error(e);
        return false;
    }
    return false;
}\n\n`

testcases += `function checkNavBarLink() {
    try {
        if ($("nav li>a").length == 1) {
            //can have an if condition to check if the href link is same as said in index.html
            return true;
        }
        return false;
    } catch (e) {
        console.error(e);
        return false;
    }
}\n\n`

testcases += `function checkNavBarBrandName() {
    try {
        return ($("nav>a").text().trim().toLowerCase().length > 1)
    } catch (e) {
        console.error(e);
        return false;
    }
}\n\n`


/**
 * extracting all the html file URLS
 */
fs.readdirSync('../testfiles/htmlfiles').forEach(file => {
    //.split(".")[0].toLowerCase();
    let mainfilename = file + "";
    console.log("-------->", mainfilename);
    URL.push('../testfiles/htmlfiles/' + mainfilename);
})


/**
 * working on each html file to generate test cases
 */
URL.forEach(url => {
    tempcases = testcases;
    funcCalls = "";
    console.log("URL is -> ", url);
    var testcasefilename = url.split("/")[3].split(".")[0];
    fs.writeFileSync('../utilities/' + testcasefilename + '_TESTCASES.js',"");
    console.log("---------------->", testcasefilename);
    jsdom.fromFile(url, options).then(dom => {
        var window = dom.window;
        var document = window.document;
        var elements = document.getElementsByTagName("*");
        var ids = document.querySelectorAll('*[id]');
        console.log(ids, ids.length);
        //console.log(elements);
        console.log("------->", elements.length);

        /**
         * checking if the id exist in the employee code or not
         */
        let testcasename = `CheckifIDisPresent`;

        /**
         * testcase to check if the certain id and element name match or not
         */
        let testcase = `/**
             *  This is the function to check if the tag with specific ID 
             *  is present or not 
             */
            function ${testcasename}(id,elementName){
            if($('#' + id)[0].length==1 && elementName == "$('#' + id)[0].tagName"){
                return true;
            }else{
                return false;
            }
            }\n\n`

        tempcases += testcase;
        for (let i = 0; i < ids.length; i++) {
            funcCalls += `var testcase_${testcasename}_${String(ids[i].id)} = ${testcasename}('${String(ids[i].id)}','${ids[i].tagName}');
            if(testcase_${testcasename}_${String(ids[i].id)}){
                scores['testcase_${testcasename}_${String(ids[i].id)}'] = 0.5;
                TotalScore+=0.5;
            }else{
                scores['testcase_${testcasename}_${String(ids[i].id)}'] = 0;
            }\n\n`
        }

        //console.log("1111111111111",tempcases);
        /**
         * To check if the elements have respective classes or not
         */

        testcasename = `CheckClassNameForTag`
        testcase = `/**
        *   This is the function to check Classes for all tags
        */ 
       function ${testcasename}(tagName,classname,Parent){
            let tagName_elements = $(String(tagName));
            for(let i=0;i<tagName_elements.length;i++){
                if(tagName_elements[i].parentElement.tagName==Parent){
                    let classes = tagName_elements[i].className.split(" ");
                    if(classes.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }
            }
            return false;
        }\n\n`

        tempcases += testcase;
        let classes = [];
        for (let i = 1; i < elements.length; i++) {
            /**
             * This is the part after verifying the tag
             * where we check for the classes
             */
            classes = elements[i].className.split(" ");
            if (classes.length == 1 && classes[0] == "") {
            } else {
                for (let j = 0; j < classes.length; j++) {
                    funcCalls += `var testcase_${testcasename}_B${i}${j} = ${testcasename}('${String(elements[i].tagName)}','${String(classes[j])}','${String(elements[i].parentElement.tagName)}')
                if(testcase_${testcasename}_B${i}${j}){
                    scores['testcase_${testcasename}_B${i}${j}'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_${testcasename}_B${i}${j}'] = 0;
                }\n\n`
                }
            }
        }
        //console.log("222222222222",tempcases);
        /**
         * This is to check the classes for every special ID
         */

        testcasename = `CheckclassNameforid`
        testcase = `/**
            * This is the function to check if each ID
            * has the respective classes or not
            */ 
            function ${testcasename}(id,classname){
                if($('#'+id)){
                    let classes = $('#'+id).className.split(" ");
                    if(classes.indexOf(classname)!=-1){
                        return true;
                    }else{
                        return false;
                    }
                }
            }\n\n`
        tempcases += testcase;
        let classnames = [];

        for (let i = 0; i < ids.length; i++) {
            classnames = ids[i].className.split(" ");
            if (classnames.length == 1 && classnames[0] == "") {

            } else {
                for (let j = 0; j < classnames.length; j++) {
                    funcCalls += `var testcase_${testcasename}_${String(ids[i].id)} = ${testcasename}('${String(ids[i].id)}','${classnames[j]}');
                if(testcase_${testcasename}_${String(ids[i].id)}){
                    scores['testcase_${testcasename}_${String(ids[i].id)}'] = 0.5;
                    TotalScore+=0.5;
                }else{
                    scores['testcase_${testcasename}_${String(ids[i].id)}'] = 0;
                }\n\n`
                }
            }
        }
        //console.log("3333333333",tempcases);
        /**
         * Funtions to check if the elements with special ids contain the css styles
         * or not
         */

    //     testcasename = `CheckForStyleID`;
    //     testcase = `/**
    //     * Function to check if the element with the special id has the required css
    //     * property or not
    //     */
    // function ${testcasename} (id, cssProperty, cssValue){
    //     if ($('#' + id).length == 1) {
    //         let values = Object.values($('#' + id)[0].style);
    //         if (values.indexOf(cssProperty) != -1) {
    //             if ($('#' + id)[0].style[cssProperty] == cssValue) {
    //                 return true;
    //             } else {
    //                 return false;
    //             }
    //         }
    //     }
    // }\n\n`
    //     tempcases += testcase;
    //     for (let i = 0; i < ids.length; i++) {
    //         let styles = Object.values($('#' + String(ids[i].id))[0].style);
    //         for (let j = 0; j < styles.length; j++) {
    //             funcCalls += `var testcase_${testcasename}_${String(ids[i].id)} = ${testcasename}(${String(ids[i].id)}, ${String(styles[j])}, ${$('#' + String(ids[i].id))[0].style[String(styles[j])]})
    //         if (testcase_${ testcasename}_${String(ids[i].id)}){
    //         scores['testcase_${testcasename}_${String(ids[i].id)}'] = 0.5;
    //         TotalScore += 0.5;
    //     }else {
    //         scores['testcase_${testcasename}_${String(ids[i].id)}'] = 0;
    //     } \n\n`
    //         }
    //     }


        /**
        * Writing the testcases to seperate files;
        */
       console.log("********--------------------------------------********");
       if(testcasefilename=="index"){
            tempfile = `(function () {
                var sum = 0;
                for (property in scores) {
        
                    if (scores[property] == 0) {
                        console.error(property + "=>" + scores[property])
                    } else {
                        console.log(property + "=>" + scores[property]);
                    }
                    sum = sum + scores[property];
                }
                console.log("Sum is " + sum);
        
        
                var indexData = {
                    "empId": $("#tt_empId").text(),
                    "examID": $("#tt_examId").text(),
                    "indexTestcases": scores,
                    "registerTestcases": null,
                    "totalMarks": sum
                }
        
                console.log(indexData);
                localStorage.removeItem(indexData.empId);
                localStorage.setItem(indexData.empId, JSON.stringify(indexData));
        
        
            })();`
            var finaltext = maincode + funcCalls + tempfile + '})\n' + String(tempcases);
        }else if(testcasefilename=="booking"){
            tempcases += `function displayMarks() {
                var sum = 0;
                for (property in scores) {
        
                    if (scores[property] == 0) {
                        console.error(property + "=>" + scores[property])
                    } else {
                        console.log(property + "=>" + scores[property]);
                    }
                    sum = sum + scores[property];
                }
                console.log("Sum is " + sum);
        
                var score = JSON.parse(localStorage.getItem($("#tt_empId").text()));
                score.registerTestcases = scores;
        
                score.totalMarks = sum + score.totalMarks;
        
                console.log("Regiter score is " + JSON.stringify(score));
        
        
                var xmlhttp = new XMLHttpRequest(); // new HttpRequest instance 
                xmlhttp.open("POST", "http://localhost:3000/post");
                xmlhttp.setRequestHeader("Content-Type", "application/json");
                xmlhttp.send(JSON.stringify(score));
        
            };`
            var finaltext = maincode + funcCalls + 'displayMarks();\n})\n' + tempcases;
        }
        //var finaltext = maincode + funcCalls + '})\n' + String(tempcases);
        fs.appendFileSync('../utilities/' + testcasefilename + '_TESTCASES.js', finaltext);
        console.log(testcasefilename, "<-------");
    }).catch(e => {
        console.log(e);
    })
})

console.log("The testcases have been formed for all the files");
console.log(`
||||||||         |||||||||||      |||\\\          |||      ||||||||||||||
|       ||       ||       ||      |||  \\\        |||      |||      
|       ||       ||       ||      |||    \\\      |||      |||||||||
|       ||       ||       ||      |||      \\\    |||      |||||||||
|       ||       ||       ||      |||        \\\  |||      |||
||||||||         |||||||||||      |||          \\\|||      ||||||||||||||
`);