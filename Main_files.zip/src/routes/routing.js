const express = require('express');
const router = express.Router();
const fs = require('fs');

router.get("/",(req,res)=>{
    res.sendFile("../utilities/solution.html");
    res.end();
})

router.post("/maketestcases",(req,res)=>{
    var testcaseobj = req.body;
    console.log(testcaseobj);
    fs.appendFileSync("../testcases.txt",testcaseobj);
})

module.exports = router;