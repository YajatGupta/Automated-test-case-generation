const fs = require('fs');
const fse = require('fse');
const express = require('express');
const kill = require('kill-port');
const path = require('path');
const functions = require('../src/utilities/trialrun');
const jquery = require('jquery');

const app = express();

app.get("/",(req,res)=>{
    console.log(__dirname);
    res.sendfile(path.join(__dirname,"/utilities/solution.html"));
})

app.get("/test",(req,res)=>{
    functions.trialfunction();
})

app.listen(3000,()=>console.log("server is started on port 3000"));