var cmd     = require('node-command-line'),
Promise = require('bluebird');
var fs = require('fs');

    function runMultipleCommandWithWait1() {
      console.log("Starting the commands")
        Promise.coroutine(function *() {
          var commands = ["node unzip1","node addScript"];
          for(var i=0; i < commands.length; i++) {
            yield cmd.run(commands[i]);
          }
          console.log('Unzipped and added the scripts');
          runServer();
      })();
    }

    function runServer(){
      hostedFolder='./hosted';
      nfiles=[]
      fs.readdirSync(hostedFolder).forEach(file => {        
          nfiles.push(file);
      })
      for(j=0;j<nfiles.length;j++){      
        console.log("./hosted/"+nfiles[j]);
          
        server="http-server ./hosted/"+nfiles[j]+" -o -p 558"+j
        runMultipleCommandWithWait2(server)
      }
    }


    function runMultipleCommandWithWait2(server) {
      console.log("Starting the server now...")
      
        Promise.coroutine(function *() {
          var commands = [server];
          for(var i=0; i < commands.length; i++) {
            yield cmd.run(commands[i]);
          }
        })();
      }
      runMultipleCommandWithWait1();
    

      