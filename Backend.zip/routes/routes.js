var express = require('express');
var routing = express.Router();

var toolDAL = require('../public/javascripts/toolDAL');



routing.post("/post",function(request,response){
    obj = request.body
    console.log(obj);
    console.log("Exam ID " + obj.examID + " " + obj.examId);
    toolDAL.appendMarks(obj).then(function (result) {
        console.log("First Time",obj.examId);
        console.log("-----------------")
        console.log("routes Post",result);
        response.json({ "message": "marks inserted for the employee :"+result.empId});
    }).catch(function (err) {
        console.log("error in post request",err.message);
    })
})

routing.get('/getEmp/:examId',function(request,response){
    // response.json({"message": "You are using express.Router class in POST method"});
    toolDAL.findEmp(request.params.examId).then(function (employee) {
        // console.log("empId",request.params.examId)
        // console.log("routes get",employee)
        response.json(employee)
    }).catch(function (err) {
        console.log(err.message);
    })
})
module.exports = routing