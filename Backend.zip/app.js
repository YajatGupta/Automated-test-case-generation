var express = require('express');
var bodyParser = require('body-parser');
var router = require('./routes/routes');
// var myErrorLogger = require('./public/javascripts/ErrorLogger');
// var myRequestLogger = require('./public/javascripts/RequestLogger');

var cors = require('cors');
var app = express();
app.use(cors());

app.use(bodyParser.json());
// app.use(myRequestLogger);

app.use('/', router);

// app.use(myErrorLogger);
var port = 3000;
app.listen(port);
console.log("Server listening in port ",port);
